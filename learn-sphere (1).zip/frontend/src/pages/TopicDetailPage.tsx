import React, { useEffect, useState } from "react";
import { useSearchParams, useNavigate, Link } from "react-router-dom";
import brain from "../brain";
import { ForumTopicResponse } from "../brain/data-contracts"; // Assuming this type exists and is relevant
import { useCurrentUser } from "app";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Loader2, AlertTriangle, ArrowLeft, MessageCircle, User, CalendarDays } from "lucide-react";
import { toast } from "sonner";

const TopicDetailPage = () => {
  const [searchParams] = useSearchParams();
  const navigate = useNavigate();
  const communityId = searchParams.get("communityId");
  const topicId = searchParams.get("topicId");

  const { user: currentUser, loading: userLoading } = useCurrentUser();

  const [topic, setTopic] = useState<ForumTopicResponse | null>(null);
  const [isLoadingTopic, setIsLoadingTopic] = useState(true);
  const [topicError, setTopicError] = useState<string | null>(null);

  // Placeholder for author details - will need to enhance if not part of ForumTopicResponse
  // const [author, setAuthor] = useState<any | null>(null); 

  useEffect(() => {
    if (!communityId || !topicId) {
      setTopicError("Community ID or Topic ID is missing.");
      setIsLoadingTopic(false);
      return;
    }
    setIsLoadingTopic(true);
    setTopicError(null);
    
    brain.get_forum_topic_details({ communityId, topicId })
      .then(async (response) => {
        if (response.ok) {
          const data: ForumTopicResponse = await response.json();
          setTopic(data);
        } else {
          const errorData = await response.json().catch(() => ({ detail: "Failed to load topic details." }));
          setTopicError(errorData.detail || `Error: ${response.status}`);
        }
      })
      .catch((err) => {
        console.error(`Error fetching topic ${topicId} in community ${communityId}:`, err);
        setTopicError("An unexpected error occurred while fetching the topic.");
      })
      .finally(() => {
        setIsLoadingTopic(false);
      });

  }, [communityId, topicId]);

  const isLoading = isLoadingTopic || userLoading;

  return (
    <div className="min-h-screen w-full bg-gradient-to-br from-slate-900 via-purple-950 to-slate-900 text-white flex flex-col items-center p-4 pt-20 md:pt-24">
      <div className="w-full max-w-3xl mx-auto space-y-6">
        <Button variant="outline" onClick={() => navigate(-1)} className="mb-4 text-purple-300 border-purple-400 hover:bg-purple-700/50 hover:text-purple-200">
          <ArrowLeft className="mr-2 h-4 w-4" /> Back to Forum
        </Button>

        {isLoading && (
          <Card className="bg-slate-800/60 backdrop-blur-xl border border-purple-500/50 rounded-xl shadow-2xl">
            <CardHeader>
              <CardTitle className="text-2xl text-purple-300">Loading Topic...</CardTitle>
            </CardHeader>
            <CardContent className="flex justify-center items-center h-64">
              <Loader2 className="h-12 w-12 animate-spin text-purple-400" />
            </CardContent>
          </Card>
        )}

        {!isLoading && topicError && (
          <Card className="bg-red-900/30 border-red-700/50 text-red-200 shadow-xl">
            <CardHeader><CardTitle className="flex items-center"><AlertTriangle className="h-6 w-6 mr-2 text-red-400" />Error Loading Topic</CardTitle></CardHeader>
            <CardContent>
                <p>{topicError}</p>
                <Button asChild variant="outline" className="mt-4 border-red-400 text-red-300 hover:bg-red-800/50 hover:text-red-200">
                    <Link to={`/CommunityForumPage?id=${communityId || ''}`}>Go Back to Forum</Link>
                </Button>
            </CardContent>
          </Card>
        )}

        {!isLoading && !topicError && topic && (
          <Card className="bg-slate-800/70 backdrop-blur-lg border border-purple-600/40 rounded-xl shadow-xl">
            <CardHeader className="p-6 border-b border-purple-500/30">
              <CardTitle className="text-3xl md:text-4xl font-bold bg-clip-text text-transparent bg-gradient-to-r from-purple-400 to-pink-500 drop-shadow-sm">
                {topic.title}
              </CardTitle>
              <div className="flex items-center space-x-4 text-sm text-slate-400 mt-3">
                <div className="flex items-center">
                  <User className="h-4 w-4 mr-1.5 text-purple-400" /> 
                  <span>{topic.author_display_name || "Unknown User"}</span>
                </div>
                <div className="flex items-center">
                  <CalendarDays className="h-4 w-4 mr-1.5 text-purple-400" /> 
                  <span>{new Date(topic.created_at).toLocaleDateString('en-US', { year: 'numeric', month: 'long', day: 'numeric' })}</span>
                </div>
              </div>
            </CardHeader>
            <CardContent className="p-6 prose prose-invert prose-sm md:prose-base max-w-none text-slate-200 whitespace-pre-wrap">
              {topic.content}
            </CardContent>
            {/* Placeholder for comments/replies section */}
            <CardContent className="p-6 border-t border-purple-500/30 mt-4">
                <h3 className="text-xl font-semibold text-purple-300 mb-3 flex items-center">
                    <MessageCircle className="h-5 w-5 mr-2"/> Replies
                </h3>
                <p className="text-slate-400">Replies and comment functionality will be added here.</p>
                {/* Future: Add a form to post a reply */}
                {/* Future: List replies */}
            </CardContent>
          </Card>
        )}
      </div>
    </div>
  );
};

export default TopicDetailPage;
