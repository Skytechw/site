import React, { useEffect, useMemo } from "react";
import { useSearchParams, useNavigate } from "react-router-dom"; // Changed useParams to useSearchParams
import { Button } from "@/components/ui/button";
import { ArrowLeft, Loader2, AlertTriangle } from "lucide-react";
import CommunityTabs from "components/CommunityTabs";
import useCommunityStore from "../utils/communityStore";
import { APP_BASE_PATH } from "app";

export default function CommunityHubPage() {
  const [searchParams] = useSearchParams(); // Use searchParams
  const communityId = searchParams.get("id"); // Get 'id' from query string
  const navigate = useNavigate();
  const {
    myCommunities,
    isLoadingMyCommunities,
    fetchMyCommunities,
    errorMyCommunities,
  } = useCommunityStore();

  // Fetch communities if the list is empty (e.g., direct navigation to this URL)
  useEffect(() => {
    if (!isLoadingMyCommunities && myCommunities.length === 0) {
      fetchMyCommunities();
    }
  }, [fetchMyCommunities, isLoadingMyCommunities, myCommunities.length]);

  const community = useMemo(() => {
    return myCommunities.find((c) => c.id === communityId);
  }, [myCommunities, communityId]);

  console.log(`[CommunityHubPage] Rendering for communityId: ${communityId}. Found community:`, community ? JSON.stringify(community, null, 2) : "Not found yet");

  const handleBackToDashboard = () => {
    // Simply navigate to "/", React Router will handle the APP_BASE_PATH
    navigate("/");
  };

  if (isLoadingMyCommunities && !community) {
    return (
      <div className="container mx-auto px-4 py-8 text-center flex flex-col items-center justify-center min-h-[calc(100vh-12rem)]">
        <Loader2 className="h-12 w-12 animate-spin text-purple-600 mb-4" />
        <p className="text-lg text-gray-700">Loading community details...</p>
      </div>
    );
  }

  if (errorMyCommunities) {
    return (
      <div className="container mx-auto px-4 py-8 text-center">
        <AlertTriangle className="h-12 w-12 text-red-500 mx-auto mb-4" />
        <p className="text-red-600 font-semibold mb-2">Could not load community data.</p>
        <p className="text-sm text-gray-600 mb-4">{errorMyCommunities.message}</p>
        <Button onClick={handleBackToDashboard} variant="outline">
          <ArrowLeft className="w-4 h-4 mr-1.5" />
          Back to Dashboard
        </Button>
      </div>
    );
  }
  
  if (!community && !isLoadingMyCommunities && myCommunities.length > 0) {
    // Communities loaded, but this specific one not found
    return (
      <div className="container mx-auto px-4 py-8 text-center">
        <AlertTriangle className="h-12 w-12 text-orange-500 mx-auto mb-4" />
        <p className="text-orange-600 font-semibold mb-2">Community Not Found</p>
        <p className="text-sm text-gray-600 mb-4">
          The community you are looking for does not exist or you may not have access.
        </p>
        <Button onClick={handleBackToDashboard} variant="outline">
          <ArrowLeft className="w-4 h-4 mr-1.5" />
          Back to Dashboard
        </Button>
      </div>
    );
  }

  // If community is still undefined but we are past initial loading checks for myCommunities, 
  // it might still be loading if myCommunities was initially empty and fetchMyCommunities is running.
  // This specific check ensures we wait for the community object itself if ID is present.
  if (!community) {
    return (
      <div className="container mx-auto px-4 py-8 text-center flex flex-col items-center justify-center min-h-[calc(100vh-12rem)]">
        <Loader2 className="h-12 w-12 animate-spin text-purple-600 mb-4" />
        <p className="text-lg text-gray-700">Finding community...</p>
      </div>
    );
  }

  return (
    <div className="container mx-auto px-4 py-8">
      {/* Back Navigation Button */}
      <div className="mb-6">
        <Button
          onClick={handleBackToDashboard}
          variant="outline"
          className="inline-flex items-center text-sm font-medium text-purple-600 hover:text-purple-800 hover:bg-purple-50 border-purple-300 hover:border-purple-400 transition-colors"
        >
          <ArrowLeft className="w-4 h-4 mr-1.5" />
          Back to Dashboard
        </Button>
      </div>

      {/* Community Header */}
      <header className="mb-8 p-6 bg-gradient-to-r from-purple-50 via-pink-50 to-rose-50 rounded-lg shadow-md">
        <h1 className="text-3xl md:text-4xl font-bold text-transparent bg-clip-text bg-gradient-to-r from-purple-600 to-pink-600">
          {community.name}
        </h1>
        <p className="mt-2 text-slate-600 max-w-2xl">
          {community.description}
        </p>
      </header>

      {/* Tabbed Navigation */}
      <CommunityTabs communityId={community.id} />
    </div>
  );
}
