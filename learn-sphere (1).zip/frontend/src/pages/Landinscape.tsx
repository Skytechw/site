import React from "react";
import { Link } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { Sparkles, Users, BookOpen, MessageSquare, CalendarCheck, ArrowRight } from "lucide-react"; // Added more icons

const GlassButton = ({ to, children, className, variant = "outline" }: { to: string, children: React.ReactNode, className?: string, variant?: "outline" | "default" }) => (
  <Link to={to}>
    <Button
      variant={variant as any} // Type assertion needed as shadcn Button variant might not perfectly align
      size="lg"
      className={`bg-white/10 hover:bg-white/20 backdrop-blur-md border border-white/20 text-white shadow-lg transition-all duration-300 ease-in-out transform hover:scale-105 px-8 py-3 text-lg ${className}`}
    >
      {children}
    </Button>
  </Link>
);

const FeatureCard = ({ icon: Icon, title, description }: { icon: React.ElementType, title: string, description: string }) => (
  <div className="bg-slate-800/50 backdrop-blur-lg p-6 rounded-xl shadow-2xl border border-purple-500/30 hover:border-purple-400/70 transition-all duration-300 transform hover:-translate-y-1">
    <div className="flex items-center justify-center w-12 h-12 bg-gradient-to-r from-purple-600 to-pink-600 rounded-lg mb-4 shadow-md">
      <Icon className="w-6 h-6 text-white" />
    </div>
    <h3 className="text-xl font-semibold mb-2 text-purple-300">{title}</h3>
    <p className="text-slate-400 text-sm leading-relaxed">{description}</p>
  </div>
);

const CommunityShowcaseCard = ({ name, description, imageUrl, members, courses }: { name: string, description: string, imageUrl?: string, members?: number, courses?: number }) => (
  <div className="bg-gradient-to-br from-purple-800/70 via-slate-800/60 to-pink-800/70 backdrop-blur-xl p-6 rounded-2xl shadow-2xl border border-purple-500/50 transition-all duration-300 hover:shadow-purple-500/50 hover:scale-105">
    {imageUrl && <img src={imageUrl} alt={name} className="w-full h-40 object-cover rounded-lg mb-4 shadow-lg"/>}
    {!imageUrl && <div className="w-full h-40 bg-slate-700 rounded-lg mb-4 flex items-center justify-center text-slate-500 shadow-lg"><Sparkles size={48}/></div>}
    <h3 className="text-2xl font-bold mb-2 text-transparent bg-clip-text bg-gradient-to-r from-purple-400 to-pink-400">{name}</h3>
    <p className="text-slate-300 text-sm mb-4 leading-relaxed line-clamp-3">{description}</p>
    <div className="flex justify-between text-xs text-purple-300">
      {members && <span><Users size={14} className="inline mr-1"/> {members} Members</span>}
      {courses && <span><BookOpen size={14} className="inline mr-1"/> {courses} Courses</span>}
    </div>
    <Button variant="ghost" size="sm" className="mt-4 w-full text-pink-400 hover:text-white hover:bg-pink-500/30 transition-colors">
      Explore Community <ArrowRight size={16} className="ml-2" />
    </Button>
  </div>
);

export default function LandinscapePage() {
  const features = [
    { icon: Users, title: "Vibrant Communities", description: "Connect with like-minded individuals, join discussions, and collaborate on projects in diverse communities." },
    { icon: BookOpen, title: "Interactive Courses", description: "Master new skills with expert-led courses, engaging content, and practical exercises. Learn at your own pace." },
    { icon: MessageSquare, title: "Dynamic Forums", description: "Ask questions, share insights, and participate in active forum discussions on a wide range of topics." },
    { icon: CalendarCheck, title: "Creator Connections", description: "Book sessions with creators, attend live events, and get personalized guidance from experts in their fields." },
  ];

  const exampleCommunities = [
    { name: "AI Innovators Hub", description: "Dive into the world of Artificial Intelligence. Share projects, discuss breakthroughs, and learn from leading AI practitioners.", members: 1200, courses: 15, imageUrl: "https://images.unsplash.com/photo-1516110833968-665b646b47b9?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxzZWFyY2h8Mnx8YWJzdHJhY3QlMjBmdXR1cmlzdGljJTIwbmV0d29ya3xlbnwwfHwwfHx8MA%3D%3D&auto=format&fit=crop&w=500&q=60" },
    { name: "Creative Coders Collective", description: "A space for developers who love to blend art with technology. Explore creative coding, generative art, and interactive installations.", members: 850, courses: 10, imageUrl: "https://images.unsplash.com/photo-1550751827-41378cb4f4dd?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxzZWFyY2h8M3x8YWJzdHJhY3QlMjBmdXR1cmlzdGljJTIwY29kZXxlbnwwfHwwfHx8MA%3D%3D&auto=format&fit=crop&w=500&q=60" },
    { name: "Sustainable Futures Forum", description: "Discuss and develop solutions for a sustainable future. Connect with environmentalists, innovators, and policy makers.", members: 2000, courses: 22, imageUrl: "https://images.unsplash.com/photo-1506773090264-ac0032c95269?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxzZWFyY2h8NHx8YWJzdHJhY3QlMjBmdXR1cmlzdGljJTIwZWNvfGVufDB8fDB8fHww%3D%3D&auto=format&fit=crop&w=500&q=60" },
  ];

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-900 via-purple-900 to-slate-900 text-white flex flex-col items-center justify-center p-4 md:p-8 relative overflow-x-hidden">
      {/* Hero Section */}
      <section className="min-h-screen flex flex-col items-center justify-center text-center relative w-full max-w-6xl mx-auto px-4">
        <div className="absolute inset-0 opacity-10 animate-pulse">
          <div className="absolute top-1/4 left-1/4 w-64 h-64 md:w-96 md:h-96 bg-purple-700 rounded-full filter blur-3xl"></div>
          <div className="absolute bottom-1/4 right-1/4 w-64 h-64 md:w-96 md:h-96 bg-pink-700 rounded-full filter blur-3xl"></div>
        </div>
        <div className="relative z-10 flex flex-col items-center">
          <Sparkles className="w-16 h-16 md:w-20 md:h-20 text-purple-400 mb-6 animate-pulse" />
          <h1 className="text-5xl md:text-7xl font-bold mb-6 tracking-tight bg-clip-text text-transparent bg-gradient-to-r from-purple-400 via-pink-500 to-orange-400">
            Welcome to LearnSphere
          </h1>
          <p className="text-lg md:text-xl text-slate-300 mb-10 leading-relaxed max-w-2xl">
            Unlock your potential. Discover communities, engage in forums, master new skills with interactive courses, and connect with creators. Your journey to knowledge begins here.
          </p>
          <div className="flex flex-col sm:flex-row gap-4">
            <GlassButton to="/login" className="w-full sm:w-auto">
              Login
            </GlassButton>
            <GlassButton to="/register-page" variant="default" className="bg-gradient-to-r from-purple-600 to-pink-600 hover:from-purple-700 hover:to-pink-700 !border-transparent shadow-xl w-full sm:w-auto">
              Sign Up
            </GlassButton>
          </div>
        </div>
      </section>

      {/* Features Section */}
      <section className="py-16 md:py-24 w-full max-w-6xl mx-auto px-4 relative z-10">
        <h2 className="text-3xl md:text-4xl font-bold text-center mb-4 bg-clip-text text-transparent bg-gradient-to-r from-purple-300 to-pink-400">Why LearnSphere?</h2>
        <p className="text-center text-slate-400 mb-12 md:mb-16 max-w-2xl mx-auto">Explore the core features that make LearnSphere the ultimate platform for knowledge sharing and creation.</p>
        <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6 md:gap-8">
          {features.map((feature) => (
            <FeatureCard key={feature.title} {...feature} />
          ))}
        </div>
      </section>

      {/* Community Showcase Section */}
      <section className="py-16 md:py-24 bg-slate-900/30 w-full">
        <div className="max-w-6xl mx-auto px-4 relative z-10">
          <h2 className="text-3xl md:text-4xl font-bold text-center mb-4 bg-clip-text text-transparent bg-gradient-to-r from-pink-400 to-orange-400">Discover Thriving Communities</h2>
          <p className="text-center text-slate-400 mb-12 md:mb-16 max-w-2xl mx-auto">Get a glimpse of the vibrant communities you can join or create. Each a unique space for learning and collaboration.</p>
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6 md:gap-8">
            {exampleCommunities.map((community) => (
              <CommunityShowcaseCard key={community.name} {...community} />
            ))}
          </div>
          <div className="text-center mt-12">
             <GlassButton to="/register-page" variant="default" className="bg-gradient-to-r from-purple-600 to-pink-600 hover:from-purple-700 hover:to-pink-700 !border-transparent shadow-xl w-full sm:w-auto">
              Join LearnSphere Today
            </GlassButton>
          </div>
        </div>
      </section>
      
      {/* Footer - ensuring it's at the very bottom of all content */}
      <footer className="w-full text-center text-slate-500 text-sm py-12 relative z-10">
        <p>&copy; {new Date().getFullYear()} LearnSphere. All rights reserved. Built with passion.</p>
      </footer>
    </div>
  );
}
