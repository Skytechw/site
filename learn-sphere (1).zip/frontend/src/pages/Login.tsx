import { SignInOrUpForm } from "app";
import { Link } from "react-router-dom";

export default function Login() {
  return (
    <div className="min-h-screen flex flex-col items-center justify-center bg-gradient-to-br from-slate-900 via-purple-950 to-slate-900 text-white p-6 md:p-8">
      <h1 className="text-4xl md:text-5xl font-bold mb-10 text-center bg-clip-text text-transparent bg-gradient-to-r from-purple-400 via-pink-400 to-orange-300 drop-shadow-md">
        Welcome to LearnSphere
      </h1>
      {/* SignInOrUpForm will have its own internal styling, we are theming around it */}
      {/* We can wrap it in a themed container if more structure is desired later */}
      <div className="bg-slate-800/60 backdrop-blur-xl p-8 md:p-10 rounded-xl shadow-2xl border border-purple-500/50 max-w-md w-full">
        <SignInOrUpForm signInOptions={{ google: true, emailAndPassword: true }} /> 
      </div>
      <p className="mt-10 text-center text-sm text-slate-300">
        No account yet?{" "}
        <Link to="/register-page" className="font-semibold text-pink-400 hover:text-pink-300 hover:underline transition-colors duration-150">
          Sign up here
        </Link>
      </p>
    </div>
  );
}