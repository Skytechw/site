import React, { useEffect, useState } from "react";
import { useSearchParams, useNavigate, Link } from "react-router-dom";
import brain from "../brain";
import { 
  CommunityResponse, 
  ForumCategoryResponse, 
  ForumCategoryCreateRequest, 
  ForumCategoryUpdateRequest,
  ForumTopicResponse, // Added
  ForumTopicListResponse // Added
} from "../brain/data-contracts";
import { useCurrentUser } from "app";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription,
  DialogFooter,
  DialogClose,
} from "@/components/ui/dialog";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
  AlertDialogTrigger,
} from "@/components/ui/alert-dialog" // Added AlertDialog components
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"; // Added Select
import { toast } from "sonner";
import { Loader2, MessageSquarePlus, AlertTriangle, PlusCircle, Settings, Trash2 } from "lucide-react";

const CommunityForumPage = () => {
  const [searchParams] = useSearchParams();
  const navigate = useNavigate();
  const communityId = searchParams.get("id");

  const { user: currentUser, loading: userLoading } = useCurrentUser();

  const [community, setCommunity] = useState<CommunityResponse | null>(null);
  const [isAdmin, setIsAdmin] = useState(false);
  const [isLoadingCommunity, setIsLoadingCommunity] = useState(true);
  const [communityError, setCommunityError] = useState<string | null>(null);

  const [forumCategories, setForumCategories] = useState<ForumCategoryResponse[]>([]);
  const [isLoadingCategories, setIsLoadingCategories] = useState(false);
  const [categoriesError, setCategoriesError] = useState<string | null>(null);

  // State for selected category and its topics
  const [selectedCategory, setSelectedCategory] = useState<ForumCategoryResponse | null>(null);
  const [categoryTopics, setCategoryTopics] = useState<ForumTopicResponse[]>([]);
  const [isLoadingCategoryTopics, setIsLoadingCategoryTopics] = useState(false);
  const [categoryTopicsError, setCategoryTopicsError] = useState<string | null>(null);

  const [showCreateCategoryDialog, setShowCreateCategoryDialog] = useState(false);
  const [newCategoryName, setNewCategoryName] = useState("");
  const [newCategoryDescription, setNewCategoryDescription] = useState("");
  const [isCreatingCategory, setIsCreatingCategory] = useState(false);

  const [showEditCategoryDialog, setShowEditCategoryDialog] = useState(false);
  const [editingCategory, setEditingCategory] = useState<ForumCategoryResponse | null>(null);
  const [editCategoryName, setEditCategoryName] = useState("");
  const [editCategoryDescription, setEditCategoryDescription] = useState("");
  const [isUpdatingCategory, setIsUpdatingCategory] = useState(false);

  // Dialog states for Delete Category
  const [deletingCategory, setDeletingCategory] = useState<ForumCategoryResponse | null>(null);
  const [isDeletingCategory, setIsDeletingCategory] = useState(false);

  // State for Latest Topics
  const [latestTopics, setLatestTopics] = useState<ForumTopicResponse[]>([]);
  const [isLoadingLatestTopics, setIsLoadingLatestTopics] = useState(false);
  const [latestTopicsError, setLatestTopicsError] = useState<string | null>(null);

  // State for Create Topic Dialog
  const [showCreateTopicDialog, setShowCreateTopicDialog] = useState(false);
  const [newTopicTitle, setNewTopicTitle] = useState("");
  const [newTopicContent, setNewTopicContent] = useState("");
  const [newTopicTargetCategoryId, setNewTopicTargetCategoryId] = useState<string>(""); // ID of category for new topic
  const [isCreatingTopic, setIsCreatingTopic] = useState(false);

  // Reset selected category if community changes
  useEffect(() => {
    setSelectedCategory(null);
    setCategoryTopics([]);
  }, [communityId]);

  useEffect(() => {
    if (!communityId) {
      setCommunityError("No community ID provided.");
      setIsLoadingCommunity(false);
      return;
    }
    setIsLoadingCommunity(true);
    brain.get_community_details({ communityId })
      .then(async (response) => {
        if (response.ok) {
          const data = await response.json();
          setCommunity(data);
        } else {
          const errorData = await response.json().catch(() => ({ detail: "Failed to fetch community details." }));
          setCommunityError(errorData.detail || `Error: ${response.status}`);
        }
      })
      .catch((err) => {
        console.error("Error fetching community details:", err);
        setCommunityError("An unexpected error occurred while fetching community information.");
      })
      .finally(() => setIsLoadingCommunity(false));
  }, [communityId]);

  useEffect(() => {
    if (community && currentUser) {
      setIsAdmin(community.creator_id === currentUser.uid);
    }
  }, [community, currentUser]);

  const fetchCategories = async () => {
    if (!communityId) return;
    setIsLoadingCategories(true);
    setCategoriesError(null);
    try {
      const response = await brain.list_forum_categories({ communityId });
      if (response.ok) {
        const data = await response.json();
        setForumCategories(data);
      } else {
        const errorData = await response.json().catch(() => ({ detail: "Failed to load forum categories." }));
        setCategoriesError(errorData.detail || `Error: ${response.status}`);
      }
    } catch (err) {
      console.error("Error fetching forum categories:", err);
      setCategoriesError("An unexpected error occurred while fetching categories.");
    } finally {
      setIsLoadingCategories(false);
    }
  };

  useEffect(() => {
    fetchCategories();
  }, [communityId]);

  const fetchCategoryTopics = async (catId: string) => {
    if (!communityId) return;
    setIsLoadingCategoryTopics(true);
    setCategoryTopicsError(null);
    setCategoryTopics([]);
    try {
      const response = await brain.list_forum_topics_in_category({ communityId, categoryId: catId, limit: 50 }); // Fetch up to 50 topics for now
      if (response.ok) {
        const data: ForumTopicListResponse = await response.json();
        setCategoryTopics(data.topics);
      } else {
        const errorData = await response.json().catch(() => ({ detail: "Failed to load topics for this category." }));
        setCategoryTopicsError(errorData.detail || `Error: ${response.status}`);
      }
    } catch (err) {
      console.error(`Error fetching topics for category ${catId}:`, err);
      setCategoryTopicsError("An unexpected error occurred while fetching topics for this category.");
    } finally {
      setIsLoadingCategoryTopics(false);
    }
  };

  const handleCategoryClick = (category: ForumCategoryResponse) => {
    if (selectedCategory?.id === category.id) {
      // If clicking the same category again, deselect it or toggle view (for now, deselect)
      setSelectedCategory(null);
      setCategoryTopics([]);
      setCategoryTopicsError(null);
    } else {
      setSelectedCategory(category);
      fetchCategoryTopics(category.id);
    }
  };

  // Fetch Latest Topics
  const fetchLatestTopics = async () => {
    if (!communityId) return;
    setIsLoadingLatestTopics(true);
    setLatestTopicsError(null);
    try {
      const response = await brain.list_latest_forum_topics_in_community({ communityId, limit: 10 }); // Fetch top 10 for now
      if (response.ok) {
        const data: ForumTopicListResponse = await response.json();
        setLatestTopics(data.topics);
      } else {
        const errorData = await response.json().catch(() => ({ detail: "Failed to load latest topics." }));
        setLatestTopicsError(errorData.detail || `Error: ${response.status}`);
      }
    } catch (err) {
      console.error("Error fetching latest topics:", err);
      setLatestTopicsError("An unexpected error occurred while fetching latest topics.");
    } finally {
      setIsLoadingLatestTopics(false);
    }
  };

  useEffect(() => {
    if (!communityId) return;
    fetchLatestTopics(); // Call the function here
  }, [communityId]);

  const handleOpenCreateTopicDialog = () => {
    setNewTopicTitle("");
    setNewTopicContent("");
    // If a category is already selected on the page, default to it
    // Otherwise, user will have to pick from dropdown. Reset to empty string to ensure controlled Select component.
    setNewTopicTargetCategoryId(selectedCategory ? selectedCategory.id : (forumCategories.length > 0 ? "" : "")); 
    setShowCreateTopicDialog(true);
  };

  const handleCreateTopic = async () => {
    if (!communityId || !newTopicTargetCategoryId || !newTopicTitle.trim() || !newTopicContent.trim()) {
      toast.error("Category, title, and content are required to create a topic.");
      return;
    }
    setIsCreatingTopic(true);
    try {
      const response = await brain.create_forum_topic(
        { communityId, categoryId: newTopicTargetCategoryId }, 
        { title: newTopicTitle.trim(), content: newTopicContent.trim() }
      );
      if (response.ok) {
        toast.success("Topic created successfully!");
        setShowCreateTopicDialog(false);
        
        // Find the category object that the topic was created in
        const targetCategory = forumCategories.find(cat => cat.id === newTopicTargetCategoryId);
        if (targetCategory) {
          setSelectedCategory(targetCategory); // Set this as the currently viewed category
          fetchCategoryTopics(newTopicTargetCategoryId); // Fetch its topics
        } else {
          // Fallback if category somehow not found in state (e.g., list was refreshed externally)
          // Clear selection to avoid showing stale category topics, or fetch all categories again.
          // For now, just clear and rely on latest topics.
          setSelectedCategory(null);
          setCategoryTopics([]);
        }
        fetchLatestTopics(); // Always refresh latest topics
      } else {
        const errorData = await response.json().catch(() => ({ detail: "Failed to create topic." }));
        toast.error(errorData.detail || `Error: ${response.status}`);
      }
    } catch (err) {
      console.error("Error creating topic:", err);
      toast.error("An unexpected error occurred while creating the topic.");
    } finally {
      setIsCreatingTopic(false);
    }
  };

  const handleCreateCategory = async () => {
    if (!communityId || !newCategoryName.trim()) {
      toast.error("Category name cannot be empty.");
      return;
    }
    setIsCreatingCategory(true);
    const payload: ForumCategoryCreateRequest = { name: newCategoryName.trim(), description: newCategoryDescription.trim() };
    try {
      const response = await brain.create_forum_category({ communityId }, payload);
      if (response.ok) {
        toast.success("Forum category created successfully!");
        setShowCreateCategoryDialog(false);
        setNewCategoryName("");
        setNewCategoryDescription("");
        fetchCategories();
      } else {
        const errorData = await response.json().catch(() => ({ detail: "Failed to create category." }));
        toast.error(errorData.detail || `Error: ${response.status}`);
      }
    } catch (err) {
      console.error("Error creating forum category:", err);
      toast.error("An unexpected error occurred while creating the category.");
    } finally {
      setIsCreatingCategory(false);
    }
  };

  const handleOpenEditDialog = (category: ForumCategoryResponse) => {
    setEditingCategory(category);
    setEditCategoryName(category.name);
    setEditCategoryDescription(category.description || "");
    setShowEditCategoryDialog(true);
  };

  const handleUpdateCategory = async () => {
    if (!communityId || !editingCategory || !editCategoryName.trim()) {
      toast.error("Category name cannot be empty.");
      return;
    }
    setIsUpdatingCategory(true);
    const payload: ForumCategoryUpdateRequest = { name: editCategoryName.trim(), description: editCategoryDescription.trim() };
    try {
      const response = await brain.update_forum_category({ communityId, categoryId: editingCategory.id }, payload);
      if (response.ok) {
        toast.success("Forum category updated successfully!");
        setShowEditCategoryDialog(false);
        setEditingCategory(null);
        fetchCategories();
      } else {
        const errorData = await response.json().catch(() => ({ detail: "Failed to update category." }));
        toast.error(errorData.detail || `Error: ${response.status}`);
      }
    } catch (err) {
      console.error("Error updating forum category:", err);
      toast.error("An unexpected error occurred while updating the category.");
    } finally {
      setIsUpdatingCategory(false);
    }
  };

  const handleDeleteCategory = async () => {
    if (!communityId || !deletingCategory) {
      toast.error("No category selected for deletion.");
      return;
    }
    setIsDeletingCategory(true);
    try {
      const response = await brain.delete_forum_category({ communityId, categoryId: deletingCategory.id });
      if (response.ok) {
        toast.success("Forum category deleted successfully!");
        setDeletingCategory(null); // Clear the category to be deleted
        fetchCategories(); // Refresh the list
        // The AlertDialog will close itself on AlertDialogAction click if not prevented
      } else {
        const errorData = await response.json().catch(() => ({ detail: "Failed to delete category." }));
        toast.error(errorData.detail || `Error: ${response.status}`);
      }
    } catch (err) {
      console.error("Error deleting forum category:", err);
      toast.error("An unexpected error occurred while deleting the category.");
    } finally {
      setIsDeletingCategory(false);
    }
  };

  const isLoading = isLoadingCommunity || userLoading;
  const error = communityError;

  return (
    <div className="min-h-screen w-full bg-gradient-to-br from-slate-900 via-purple-950 to-slate-900 text-white flex flex-col items-center p-4 pt-20 md:pt-24">
      <div className="w-full max-w-5xl mx-auto space-y-6">
        {/* Loading and Error States for Community */}
        {isLoading && <div className="flex justify-center items-center h-64"><Loader2 className="h-12 w-12 animate-spin text-purple-400" /><p className="ml-4 text-xl text-slate-300">Loading Community Forum...</p></div>}
        {error && !isLoading && (
          <Card className="bg-red-900/30 border-red-700/50 text-red-200 shadow-xl">
            <CardHeader><CardTitle className="flex items-center"><AlertTriangle className="h-6 w-6 mr-2 text-red-400" />Error Loading Community</CardTitle></CardHeader>
            <CardContent><p>{error}</p><Button onClick={() => navigate("/")} variant="outline" className="mt-4 border-red-400 text-red-300 hover:bg-red-800/50 hover:text-red-200">Go to Homepage</Button></CardContent>
          </Card>
        )}

        {/* Community Content */}
        {!isLoading && !error && community && (
          <>
            <Card className="bg-slate-800/60 backdrop-blur-xl border border-purple-500/50 rounded-xl shadow-2xl overflow-hidden">
              {/* ... Community header ... */}
              <CardHeader className="p-6 md:p-8 border-b border-purple-500/30">
                <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
                  <div>
                    <CardTitle className="text-3xl md:text-4xl font-bold bg-clip-text text-transparent bg-gradient-to-r from-purple-400 to-pink-500 drop-shadow-sm">{community.name}</CardTitle>
                    {community.description && <CardDescription className="text-slate-300 mt-1 text-base">{community.description}</CardDescription>}
                    {isAdmin && <p className="text-sm text-green-400 mt-1">(Admin View)</p>}
                  </div>
                  <Button 
                    size="lg" 
                    className="bg-gradient-to-r from-pink-500 to-orange-500 hover:from-pink-600 hover:to-orange-600 text-white font-semibold py-3 px-6 rounded-lg shadow-lg hover:shadow-xl transition-all duration-150 ease-in-out transform hover:scale-105 active:scale-95 focus:outline-none focus:ring-2 focus:ring-pink-500 focus:ring-opacity-60 shrink-0"
                    onClick={handleOpenCreateTopicDialog} // Updated onClick
                    disabled={forumCategories.length === 0 && !isAdmin} // Disable if no categories and not admin (admin can create cats)
                  >
                    <MessageSquarePlus className="mr-2 h-5 w-5" />Start New Discussion
                  </Button>
                  {forumCategories.length === 0 && !isAdmin && <p className="text-xs text-orange-400 mt-1 text-right">No categories available to post.</p> }
                </div>
              </CardHeader>
            </Card>

            <Card className="bg-slate-800/70 backdrop-blur-lg border border-purple-600/40 rounded-xl shadow-xl">
              <CardHeader className="flex flex-row justify-between items-center p-6">
                <CardTitle className="text-2xl text-slate-200">Forum Categories</CardTitle>
                {isAdmin && (
                  <Button variant="outline" className="text-purple-300 border-purple-400 hover:bg-purple-700/50 hover:text-purple-200" onClick={() => setShowCreateCategoryDialog(true)}>
                    <PlusCircle className="mr-2 h-5 w-5" />New Category
                  </Button>
                )}
              </CardHeader>
              <CardContent className="p-6">
                {isLoadingCategories && <div className="flex justify-center items-center py-8"><Loader2 className="h-8 w-8 animate-spin text-purple-300" /><p className="ml-3 text-slate-400">Loading categories...</p></div>}
                {!isLoadingCategories && categoriesError && <div className="text-center py-8 text-red-400"><AlertTriangle className="h-8 w-8 mx-auto mb-2" /><p>{categoriesError}</p></div>}
                {!isLoadingCategories && !categoriesError && forumCategories.length === 0 && <p className="text-center text-slate-400 py-8">No categories created yet. {isAdmin ? "Create one to get started!" : ""}</p>}
                {!isLoadingCategories && !categoriesError && forumCategories.length > 0 && (
                  <div className="space-y-4">
                    {forumCategories.map((category) => (
                      <Card 
                        key={category.id} 
                        className={`bg-slate-700/50 border-slate-600 hover:shadow-purple-500/20 hover:shadow-md transition-all cursor-pointer ${selectedCategory?.id === category.id ? 'ring-2 ring-purple-500 shadow-purple-500/30' : 'hover:border-purple-400'}`}
                        onClick={() => handleCategoryClick(category)}
                      >
                        <CardHeader className="flex flex-row justify-between items-center p-4">
                          <div>
                            <CardTitle className="text-lg text-purple-300">{category.name}</CardTitle>
                            {category.description && <CardDescription className="text-slate-400 text-sm mt-1">{category.description}</CardDescription>}
                          </div>
                          {isAdmin && (
                            <div className="flex items-center space-x-2">
                              <Button variant="ghost" size="sm" className="text-slate-400 hover:text-slate-200" onClick={() => handleOpenEditDialog(category)}><Settings className="h-4 w-4" /></Button>
                              <AlertDialog onOpenChange={(open) => {if (!open) setDeletingCategory(null);}}>
                                <AlertDialogTrigger asChild>
                                  <Button variant="ghost" size="sm" className="text-red-500 hover:text-red-400" onClick={() => setDeletingCategory(category)}>
                                    <Trash2 className="h-4 w-4" />
                                  </Button>
                                </AlertDialogTrigger>
                                <AlertDialogContent className="bg-slate-800 border-purple-600 text-slate-100">
                                  <AlertDialogHeader>
                                    <AlertDialogTitle className="text-red-400">Are you absolutely sure?</AlertDialogTitle>
                                    <AlertDialogDescription className="text-slate-300">
                                      This action cannot be undone. This will permanently delete the category "<strong>{deletingCategory?.name}</strong>" and all its associated discussions.
                                    </AlertDialogDescription>
                                  </AlertDialogHeader>
                                  <AlertDialogFooter>
                                    <AlertDialogCancel className="text-slate-300 border-slate-500 hover:bg-slate-700">Cancel</AlertDialogCancel>
                                    <AlertDialogAction onClick={handleDeleteCategory} disabled={isDeletingCategory} className="bg-red-600 hover:bg-red-700 text-white disabled:opacity-50">
                                      {isDeletingCategory ? <Loader2 className="mr-2 h-4 w-4 animate-spin" /> : null}Delete Category
                                    </AlertDialogAction>
                                  </AlertDialogFooter>
                                </AlertDialogContent>
                              </AlertDialog>
                            </div>
                          )}
                        </CardHeader>
                      </Card>
                    ))}
                  </div>
                )}
              </CardContent>
            </Card>

            {/* Topics in Selected Category Section */}
            {selectedCategory && (
              <Card className="bg-slate-800/70 backdrop-blur-lg border border-purple-600/40 rounded-xl shadow-xl mt-6">
                <CardHeader className="p-6">
                  <CardTitle className="text-2xl text-slate-200">Topics in {selectedCategory.name}</CardTitle>
                </CardHeader>
                <CardContent className="p-6">
                  {isLoadingCategoryTopics && <div className="flex justify-center items-center py-8"><Loader2 className="h-8 w-8 animate-spin text-purple-300" /><p className="ml-3 text-slate-400">Loading topics...</p></div>}
                  {!isLoadingCategoryTopics && categoryTopicsError && <div className="text-center py-8 text-red-400"><AlertTriangle className="h-8 w-8 mx-auto mb-2" /><p>{categoryTopicsError}</p></div>}
                  {!isLoadingCategoryTopics && !categoryTopicsError && categoryTopics.length === 0 && <p className="text-center text-slate-400 py-8">No topics found in this category. {isAdmin ? "Be the first to create one!" : ""}</p>}
                  {!isLoadingCategoryTopics && !categoryTopicsError && categoryTopics.length > 0 && (
                    <ul className="space-y-3">
                      {categoryTopics.map((topic) => (
                        <li key={topic.id} className="rounded-lg hover:bg-slate-600/60 transition-colors">
                          <Link to={`/TopicDetailPage?communityId=${communityId}&topicId=${topic.id}`} className="block p-3">
                            <h4 className="text-md font-semibold text-purple-300">{topic.title}</h4>
                            <p className="text-xs text-slate-400 mt-1">
                              Created by: {topic.author_display_name || "User"} on {new Date(topic.created_at).toLocaleDateString()}
                            </p>
                          </Link>
                        </li>
                      ))}
                    </ul>
                  )}
                </CardContent>
              </Card>
            )}

            {/* Latest Topics Section */}
            <Card className="bg-slate-800/70 backdrop-blur-lg border border-purple-600/40 rounded-xl shadow-xl">
              <CardHeader className="p-6">
                <CardTitle className="text-2xl text-slate-200">Latest Discussions</CardTitle>
              </CardHeader>
              <CardContent className="p-6">
                {isLoadingLatestTopics && <div className="flex justify-center items-center py-8"><Loader2 className="h-8 w-8 animate-spin text-purple-300" /><p className="ml-3 text-slate-400">Loading latest discussions...</p></div>}
                {!isLoadingLatestTopics && latestTopicsError && <div className="text-center py-8 text-red-400"><AlertTriangle className="h-8 w-8 mx-auto mb-2" /><p>{latestTopicsError}</p></div>}
                {!isLoadingLatestTopics && !latestTopicsError && latestTopics.length === 0 && <p className="text-center text-slate-400 py-8">No discussions started yet in this community.</p>}
                {!isLoadingLatestTopics && !latestTopicsError && latestTopics.length > 0 && (
                  <ul className="space-y-3">
                    {latestTopics.map((topic) => (
                      <li key={topic.id} className="rounded-lg hover:bg-slate-600/60 transition-colors">
                        <Link to={`/TopicDetailPage?communityId=${communityId}&topicId=${topic.id}`} className="block p-3">
                          <h4 className="text-md font-semibold text-purple-300">{topic.title}</h4>
                          <p className="text-xs text-slate-400 mt-1">
                            Created by: {topic.author_display_name || "User"} on {new Date(topic.created_at).toLocaleDateString()}
                          </p>
                        </Link>
                      </li>
                    ))}
                  </ul>
                )}
              </CardContent>
            </Card>
          </>
        )}
      </div>

      {/* Create Category Dialog */}
      <Dialog open={showCreateCategoryDialog} onOpenChange={setShowCreateCategoryDialog}>
        <DialogContent className="sm:max-w-[425px] bg-slate-800 border-purple-600 text-slate-100">
          <DialogHeader><DialogTitle className="text-purple-300">Create New Forum Category</DialogTitle><DialogDescription className="text-slate-400">Provide a name and an optional description for your new category.</DialogDescription></DialogHeader>
          <div className="grid gap-4 py-4">
            <div className="grid grid-cols-4 items-center gap-4"><Label htmlFor="category-name-create" className="text-right text-slate-300">Name</Label><Input id="category-name-create" value={newCategoryName} onChange={(e) => setNewCategoryName(e.target.value)} className="col-span-3 bg-slate-700 border-slate-600 focus:ring-purple-500 text-slate-100" placeholder="e.g., General Discussion" /></div>
            <div className="grid grid-cols-4 items-center gap-4"><Label htmlFor="category-description-create" className="text-right text-slate-300">Description</Label><Textarea id="category-description-create" value={newCategoryDescription} onChange={(e) => setNewCategoryDescription(e.target.value)} className="col-span-3 bg-slate-700 border-slate-600 focus:ring-purple-500 text-slate-100" placeholder="e.g., A place to discuss anything and everything." /></div>
          </div>
          <DialogFooter><DialogClose asChild><Button type="button" variant="outline" className="text-slate-300 border-slate-500 hover:bg-slate-700">Cancel</Button></DialogClose><Button type="button" onClick={handleCreateCategory} disabled={isCreatingCategory || !newCategoryName.trim()} className="bg-purple-600 hover:bg-purple-700 disabled:opacity-50">{isCreatingCategory ? <Loader2 className="mr-2 h-4 w-4 animate-spin" /> : null}Create Category</Button></DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Edit Category Dialog */}
      <Dialog open={showEditCategoryDialog} onOpenChange={setShowEditCategoryDialog}>
        <DialogContent className="sm:max-w-[425px] bg-slate-800 border-purple-600 text-slate-100">
          <DialogHeader><DialogTitle className="text-purple-300">Edit Forum Category</DialogTitle><DialogDescription className="text-slate-400">Update the name and/or description for this category.</DialogDescription></DialogHeader>
          <div className="grid gap-4 py-4">
            <div className="grid grid-cols-4 items-center gap-4"><Label htmlFor="category-name-edit" className="text-right text-slate-300">Name</Label><Input id="category-name-edit" value={editCategoryName} onChange={(e) => setEditCategoryName(e.target.value)} className="col-span-3 bg-slate-700 border-slate-600 focus:ring-purple-500 text-slate-100" placeholder="e.g., Announcements" /></div>
            <div className="grid grid-cols-4 items-center gap-4"><Label htmlFor="category-description-edit" className="text-right text-slate-300">Description</Label><Textarea id="category-description-edit" value={editCategoryDescription} onChange={(e) => setEditCategoryDescription(e.target.value)} className="col-span-3 bg-slate-700 border-slate-600 focus:ring-purple-500 text-slate-100" placeholder="Important updates and news."/></div>
          </div>
          <DialogFooter><DialogClose asChild><Button type="button" variant="outline" className="text-slate-300 border-slate-500 hover:bg-slate-700">Cancel</Button></DialogClose><Button type="button" onClick={handleUpdateCategory} disabled={isUpdatingCategory || !editCategoryName.trim()} className="bg-purple-600 hover:bg-purple-700 disabled:opacity-50">{isUpdatingCategory ? <Loader2 className="mr-2 h-4 w-4 animate-spin" /> : null}Save Changes</Button></DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Create Topic Dialog */}
      <Dialog open={showCreateTopicDialog} onOpenChange={setShowCreateTopicDialog}>
        <DialogContent className="sm:max-w-lg bg-slate-800 border-purple-600 text-slate-100">
          <DialogHeader>
            <DialogTitle className="text-purple-300">Start a New Discussion</DialogTitle>
            <DialogDescription className="text-slate-400">Share your thoughts or ask a question.</DialogDescription>
          </DialogHeader>
          <div className="grid gap-4 py-4">
            {/* Category Selection Dropdown - show if no category is selected OR if admin and multiple categories exist */} 
            {(!selectedCategory || forumCategories.length > 1) && (
              <div className="grid grid-cols-4 items-center gap-4">
                <Label htmlFor="topic-category" className="text-right text-slate-300">Category</Label>
                <Select 
                  value={newTopicTargetCategoryId} 
                  onValueChange={setNewTopicTargetCategoryId}
                  disabled={forumCategories.length === 0}
                >
                  <SelectTrigger className="col-span-3 bg-slate-700 border-slate-600 focus:ring-purple-500 text-slate-100">
                    <SelectValue placeholder={forumCategories.length > 0 ? "Select a category" : "No categories available"} />
                  </SelectTrigger>
                  <SelectContent className="bg-slate-700 border-slate-600 text-slate-100">
                    {forumCategories.map((cat) => (
                      <SelectItem key={cat.id} value={cat.id} className="hover:bg-purple-600/50 focus:bg-purple-600/50">
                        {cat.name}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
            )}
            {forumCategories.length === 0 && <p className="text-sm text-orange-400 col-span-4">A category must be created before you can post a topic. Admins can create categories.</p>}

            <div className="grid grid-cols-4 items-center gap-4">
              <Label htmlFor="topic-title" className="text-right text-slate-300">Title</Label>
              <Input 
                id="topic-title" 
                value={newTopicTitle} 
                onChange={(e) => setNewTopicTitle(e.target.value)} 
                className="col-span-3 bg-slate-700 border-slate-600 focus:ring-purple-500 text-slate-100" 
                placeholder="What's on your mind?"
                disabled={forumCategories.length === 0} 
              />
            </div>
            <div className="grid grid-cols-4 items-center gap-4">
              <Label htmlFor="topic-content" className="text-right text-slate-300">Content</Label>
              <Textarea 
                id="topic-content" 
                value={newTopicContent} 
                onChange={(e) => setNewTopicContent(e.target.value)} 
                className="col-span-3 bg-slate-700 border-slate-600 focus:ring-purple-500 text-slate-100 h-32 resize-none" 
                placeholder="Elaborate on your topic..."
                disabled={forumCategories.length === 0} 
              />
            </div>
          </div>
          <DialogFooter>
            <DialogClose asChild>
              <Button type="button" variant="outline" className="text-slate-300 border-slate-500 hover:bg-slate-700">Cancel</Button>
            </DialogClose>
            <Button 
              type="button" 
              onClick={handleCreateTopic} 
              disabled={isCreatingTopic || !newTopicTargetCategoryId || !newTopicTitle.trim() || !newTopicContent.trim() || forumCategories.length === 0}
              className="bg-purple-600 hover:bg-purple-700 disabled:opacity-50"
            >
              {isCreatingTopic ? <Loader2 className="mr-2 h-4 w-4 animate-spin" /> : null}Post Topic
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
};

export default CommunityForumPage;

