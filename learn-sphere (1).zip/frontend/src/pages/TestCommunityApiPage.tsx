import React, { useState } from "react";
import brain from "brain"; // Assuming brain is correctly set up
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { Card, CardContent, CardHeader, CardTitle, CardDescription, CardFooter } from "@/components/ui/card";
import { CommunityCreateRequest, CommunityResponse } from "types"; // Assuming types are in types.ts

export default function TestCommunityApiPage() {
  const [name, setName] = useState("Test Community Name");
  const [description, setDescription] = useState("A great description for our test community.");
  const [isLoading, setIsLoading] = useState(false);
  const [response, setResponse] = useState<CommunityResponse | null>(null);
  const [error, setError] = useState<any | null>(null);

  const handleSubmit = async (event: React.FormEvent) => {
    event.preventDefault();
    setIsLoading(true);
    setResponse(null);
    setError(null);

    const communityData: CommunityCreateRequest = {
      name,
      description,
      creator_id: "test-user-123", // Added hardcoded creator_id for testing
    };

    console.log("Sending to brain.create_community:", communityData);

    try {
      // Ensure brain.create_community is the correct method name
      const httpResponse = await brain.create_community(communityData);
      
      console.log("Raw HTTP Response:", httpResponse);

      if (httpResponse.ok) {
        const data: CommunityResponse = await httpResponse.json();
        setResponse(data);
        console.log("Success Response Data:", data);
        alert("Community created successfully! Check console.");
      } else {
        const errorData = await httpResponse.json().catch(() => ({ detail: "Failed to parse error JSON." }));
        setError({
          status: httpResponse.status,
          statusText: httpResponse.statusText,
          data: errorData,
        });
        console.error("Error Response Data:", {
          status: httpResponse.status,
          statusText: httpResponse.statusText,
          data: errorData,
        });
        alert(`Error creating community: ${httpResponse.status} ${httpResponse.statusText}. Check console.`);
      }
    } catch (err: any) {
      setError(err);
      console.error("Catch block error:", err);
      alert("An unexpected error occurred. Check console.");
    }
    setIsLoading(false);
  };

  return (
    <div className="container mx-auto p-4 flex justify-center items-start min-h-screen bg-slate-50">
      <Card className="w-full max-w-lg mt-10 shadow-xl">
        <CardHeader>
          <CardTitle className="text-2xl text-purple-700">Test Create Community API</CardTitle>
          <CardDescription>
            Use this form to test the backend's <code>create_community</code> endpoint.
          </CardDescription>
        </CardHeader>
        <form onSubmit={handleSubmit}>
          <CardContent className="space-y-6">
            <div className="space-y-2">
              <Label htmlFor="name" className="text-slate-700">Community Name</Label>
              <Input 
                id="name" 
                value={name} 
                onChange={(e) => setName(e.target.value)} 
                placeholder="Enter community name"
                required 
                className="focus:ring-purple-500 focus:border-purple-500"
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="description" className="text-slate-700">Community Description</Label>
              <Textarea 
                id="description" 
                value={description} 
                onChange={(e) => setDescription(e.target.value)} 
                placeholder="Enter community description"
                required 
                className="focus:ring-purple-500 focus:border-purple-500"
              />
            </div>
          </CardContent>
          <CardFooter className="flex flex-col items-stretch">
            <Button 
              type="submit" 
              disabled={isLoading} 
              className="w-full bg-gradient-to-r from-purple-500 to-pink-500 text-white hover:opacity-90 disabled:opacity-50"
            >
              {isLoading ? "Creating..." : "Create Community"}
            </Button>
            {response && (
              <div className="mt-6 p-4 bg-green-50 border border-green-300 rounded-md text-green-700">
                <h4 className="font-semibold">Success!</h4>
                <pre className="text-xs whitespace-pre-wrap break-all">{JSON.stringify(response, null, 2)}</pre>
              </div>
            )}
            {error && (
              <div className="mt-6 p-4 bg-red-50 border border-red-300 rounded-md text-red-700">
                <h4 className="font-semibold">Error:</h4>
                <pre className="text-xs whitespace-pre-wrap break-all">{JSON.stringify(error, null, 2)}</pre>
              </div>
            )}
          </CardFooter>
        </form>
      </Card>
    </div>
  );
}
