import React from "react";
import { Link, useNavigate } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { PlusCircle, Users, Compass, Eye, LogIn } from "lucide-react";

// Placeholder data - replace with actual data fetching and user context
const useUser = () => ({ name: "Alex Sky" }); // Placeholder for user's name

const joinedCommunities = [
  { id: "jc1", name: "Tech Innovators Hub", description: "Active discussions on AI and future tech.", members: 120, newMessages: 5 },
  { id: "jc2", name: "Creative Writers' Corner", description: "Share your latest work and get feedback.", members: 75, newMessages: 2 },
];

const explorableCommunities = [
  { id: "ec1", name: "Sustainable Living Group", description: "Tips and discussions on eco-friendly lifestyles.", members: 250 },
  { id: "ec2", name: "Indie Game Developers", description: "Collaborate and share your game dev journey.", members: 400 },
  { id: "ec3", name: "Local Foodies Network", description: "Discover hidden gems and share recipes.", members: 180 },
];

interface CommunityCardProps {
  id: string;
  name: string;
  description: string;
  members?: number;
  actionType: "view" | "join";
  onAction: (id: string) => void;
}

const CommunityCard: React.FC<CommunityCardProps> = ({ id, name, description, members, actionType, onAction }) => {
  return (
    <Card className="flex flex-col h-full transform hover:shadow-lg transition-shadow duration-300">
      <CardHeader>
        <CardTitle className="text-purple-700">{name}</CardTitle>
        {members && <CardDescription>{members} members</CardDescription>}
      </CardHeader>
      <CardContent className="flex-grow">
        <p className="text-sm text-slate-600 leading-relaxed">{description}</p>
      </CardContent>
      <CardFooter>
        <Button onClick={() => onAction(id)} className="w-full bg-gradient-to-r from-purple-500 to-pink-500 text-white hover:opacity-90">
          {actionType === "view" ? <Eye className="mr-2 h-4 w-4" /> : <LogIn className="mr-2 h-4 w-4" />}
          {actionType === "view" ? "View Community" : "Join Community"}
        </Button>
      </CardFooter>
    </Card>
  );
};

export default function UserDashboardPage() {
  const { name } = useUser();
  const navigate = useNavigate();

  const handleViewCommunity = (id: string) => {
    // Navigate to the specific community hub page, e.g., /community/id
    // For now, using the generic CommunityHubPage route
    navigate("/communityhubpage"); 
    console.log(`Viewing community: ${id}`);
  };

  const handleJoinCommunity = (id: string) => {
    // Implement join community logic
    alert(`Joining community: ${id} - (Implement me!)`);
    console.log(`Joining community: ${id}`);
  };

  return (
    <div className="container mx-auto px-4 py-8 bg-slate-50 min-h-screen">
      {/* Welcome Header */}
      <header className="mb-10 text-center md:text-left">
        <h1 className="text-3xl md:text-4xl font-bold text-slate-800">
          Welcome back, <span className="text-purple-600">{name}!</span>
        </h1>
        <p className="mt-2 text-lg text-slate-600">
          Your central hub for learning, connecting, and creating.
        </p>
      </header>

      {/* Create Community CTA - Prominent */}
      <section className="mb-12 p-6 md:p-8 bg-gradient-to-r from-purple-600 to-pink-600 rounded-xl shadow-xl text-white">
        <div className="flex flex-col md:flex-row items-center justify-between gap-6">
          <div>
            <h2 className="text-2xl md:text-3xl font-bold">Ready to Lead?</h2>
            <p className="mt-2 text-purple-100 max-w-xl">
              Share your expertise, build a following, and create a vibrant learning space. Launch your own community on LearnSphere today!
            </p>
          </div>
          <Button 
            size="lg" 
            variant="outline"
            className="bg-white text-purple-700 hover:bg-purple-50 border-transparent hover:border-purple-100 shadow-lg hover:shadow-xl transition-all duration-300 transform hover:scale-105 whitespace-nowrap"
            onClick={() => navigate("/create-community")} // Placeholder route
          >
            <PlusCircle className="mr-2 h-5 w-5" /> Create Your Community
          </Button>
        </div>
      </section>

      {/* Your Communities Section */}
      <section className="mb-12">
        <div className="flex items-center mb-6">
          <Users className="w-7 h-7 text-purple-600 mr-3" />
          <h2 className="text-2xl font-semibold text-slate-700">Your Communities</h2>
        </div>
        {joinedCommunities.length > 0 ? (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {joinedCommunities.map((community) => (
              <CommunityCard
                key={community.id}
                {...community}
                actionType="view"
                onAction={handleViewCommunity}
              />
            ))}
          </div>
        ) : (
          <div className="text-center py-10 px-6 bg-white rounded-lg shadow-md border border-slate-200">
            <Compass className="w-12 h-12 text-slate-400 mx-auto mb-4" />
            <h3 className="text-xl font-semibold text-slate-700 mb-2">You haven't joined any communities yet.</h3>
            <p className="text-slate-500 mb-4">Explore the communities below or create your own to get started!</p>
            <Button onClick={() => document.getElementById('explore-communities')?.scrollIntoView({ behavior: 'smooth' })} variant="outline">
              Explore Communities
            </Button>
          </div>
        )}
      </section>

      {/* Explore Communities Section */}
      <section id="explore-communities" className="mb-12">
        <div className="flex items-center mb-6">
          <Compass className="w-7 h-7 text-purple-600 mr-3" />
          <h2 className="text-2xl font-semibold text-slate-700">Explore Communities</h2>
        </div>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {explorableCommunities.map((community) => (
            <CommunityCard
              key={community.id}
              {...community}
              actionType="join"
              onAction={handleJoinCommunity}
            />
          ))}
        </div>
        {/* Add pagination or a "Load More" button if the list is long */}
      </section>

    </div>
  );
}
