import { auth } from "app";
import { useEffect } from "react";
import { useNavigate } from "react-router-dom";

export default function Logout() {
  const navigate = useNavigate();

  useEffect(() => {
    auth.signOut().then(() => {
      // Ensure redirection happens after signOut completes
      console.log("User signed out, redirecting to /landinscape.");
      navigate("/landinscape", { replace: true });
    }).catch(error => {
      console.error("Error signing out: ", error);
      // Optionally, still redirect or show an error message
      navigate("/landinscape", { replace: true });
    });
  }, [navigate]);

  // This component will typically not render anything visible as it redirects quickly.
  // You could show a spinner or a "Logging out..." message if preferred.
  return null;
}